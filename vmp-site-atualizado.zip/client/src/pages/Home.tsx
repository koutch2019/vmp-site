import { useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  CircleDot,
  Code2,
  Layers3,
  Menu,
  Play,
  Sparkles,
  X,
  Zap,
} from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Entendemos o desafio",
    text: "Mapeamos a rotina, os gargalos e o resultado que seu negócio precisa alcançar.",
  },
  {
    number: "02",
    title: "Desenhamos a solução",
    text: "Transformamos a ideia em fluxos claros, telas e uma experiência simples de usar.",
  },
  {
    number: "03",
    title: "Construímos com você",
    text: "Desenvolvemos, testamos e evoluímos o aplicativo até ele fazer sentido no dia a dia.",
  },
];

function DemoPhone() {
  const [screen, setScreen] = useState<"home" | "brief" | "done">("home");

  return (
    <div className="demo-shell">
      <div className="phone-glow" />
      <div className="phone">
        <div className="phone-notch" />
        {screen === "home" && (
          <div className="phone-screen animate-in">
            <div className="phone-topline">
              <span className="mini-brand">VMP <i>studio</i></span>
              <span className="online-dot"><CircleDot size={13} /> online</span>
            </div>
            <div className="phone-greeting">
              <span>Bom dia, Camila</span>
              <strong>Vamos tirar sua ideia do papel?</strong>
            </div>
            <div className="phone-stat-card">
              <div><span>Seu projeto</span><strong>Em movimento</strong></div>
              <div className="stat-ring"><span>72</span><small>%</small></div>
            </div>
            <div className="phone-section-label"><span>Próximos passos</span><span>ver tudo</span></div>
            <div className="phone-task"><div className="task-icon purple"><Layers3 size={16} /></div><div><strong>Refinar fluxo principal</strong><span>Hoje · 14:30</span></div><ChevronRight size={15} /></div>
            <div className="phone-task"><div className="task-icon lime"><Zap size={16} /></div><div><strong>Validar protótipo</strong><span>Amanhã · 09:00</span></div><ChevronRight size={15} /></div>
            <button className="phone-cta" onClick={() => setScreen("brief")}>Ver demonstração <ArrowRight size={15} /></button>
          </div>
        )}
        {screen === "brief" && (
          <div className="phone-screen animate-in">
            <button className="phone-back" onClick={() => setScreen("home")}>← voltar</button>
            <div className="phone-greeting compact"><span>Briefing do projeto</span><strong>Conte o que você precisa</strong></div>
            <div className="fake-input"><span>Nome do projeto</span><strong>Portal do cliente</strong></div>
            <div className="fake-input"><span>Objetivo principal</span><strong>Organizar pedidos</strong></div>
            <div className="choice-row"><span className="selected-choice">Web app <Check size={13} /></span><span>Mobile</span></div>
            <button className="phone-cta" onClick={() => setScreen("done")}>Enviar briefing <ArrowRight size={15} /></button>
          </div>
        )}
        {screen === "done" && (
          <div className="phone-screen success-screen animate-in">
            <div className="success-mark"><Check size={25} /></div>
            <strong>Briefing recebido</strong>
            <span>A VMP vai transformar essa ideia em uma solução feita para o seu negócio.</span>
            <button className="phone-cta" onClick={() => setScreen("home")}>Voltar ao início</button>
          </div>
        )}
        <div className="phone-home-indicator" />
      </div>
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main>
      <nav className="nav container">
        <a className="brand" href="#top" aria-label="VMP início"><span>V</span>MP<small>studio</small></a>
        <div className={`nav-links ${menuOpen ? "open" : ""}`}>
          <a href="#solucoes" onClick={() => setMenuOpen(false)}>Soluções</a>
          <a href="#apps" onClick={() => setMenuOpen(false)}>Apps</a>
          <a href="#processo" onClick={() => setMenuOpen(false)}>Processo</a>
          <a href="#demo" onClick={() => setMenuOpen(false)}>Demonstração</a>
          <a className="nav-cta" href="#conversa" onClick={() => setMenuOpen(false)}>Falar com a VMP <ArrowRight size={15} /></a>
        </div>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir menu">{menuOpen ? <X /> : <Menu />}</button>
      </nav>

      <section className="hero" id="top">
        <div className="hero-image" />
        <div className="hero-grid" />
        <div className="container hero-content">
          <div className="eyebrow"><span className="eyebrow-line" /> tecnologia feita para o seu negócio</div>
          <h1>Ideias que viram<br /><em>aplicativos</em> de verdade.</h1>
          <p className="hero-copy">A VMP cria soluções digitais sob medida para empresas que querem trabalhar melhor, atender melhor e crescer com clareza.</p>
          <div className="hero-actions"><a className="button button-primary" href="#conversa">Construir minha solução <ArrowRight size={17} /></a><a className="button button-ghost" href="#demo"><span className="play-icon"><Play size={12} fill="currentColor" /></span> Ver como funciona</a></div>
          <div className="hero-proof"><div className="proof-avatars"><span>V</span><span>M</span><span>P</span></div><span>Do primeiro rascunho<br /><strong>à solução em movimento.</strong></span></div>
        </div>
        <div className="scroll-hint"><span>scroll para explorar</span><i /></div>
      </section>

      <section className="intro section-pad" id="solucoes">
        <div className="container intro-layout">
          <div className="section-kicker">01 / o que fazemos</div>
          <div><h2>Seu negócio não é igual a nenhum outro.<br /><span>Seu app também não deveria ser.</span></h2><p className="large-copy">A gente não entrega um produto de prateleira. A VMP entra no seu contexto, entende suas necessidades e constrói a ferramenta certa para a sua operação.</p><a className="text-link" href="#processo">Conheça nosso jeito de criar <ArrowRight size={16} /></a></div>
        </div>
        <div className="container capability-grid">
          <article className="capability-card"><div className="capability-icon purple-bg"><Code2 size={22} /></div><span className="card-index">/ 01</span><h3>Aplicativos sob medida</h3><p>Funcionalidades pensadas para o seu fluxo, seu time e seus clientes — sem excesso, sem complicação.</p></article>
          <article className="capability-card featured"><div className="capability-icon lime-bg"><Sparkles size={22} /></div><span className="card-index">/ 02</span><h3>Experiências que fazem sentido</h3><p>Interface bonita é só o começo. Criamos produtos digitais intuitivos, rápidos e gostosos de usar.</p><span className="featured-stamp">feito para<br />funcionar</span></article>
          <article className="capability-card"><div className="capability-icon blue-bg"><Layers3 size={22} /></div><span className="card-index">/ 03</span><h3>Da ideia à evolução</h3><p>Você não fica sozinho depois do lançamento. A solução cresce junto com as novas necessidades.</p></article>
        </div>
      </section>

      <section className="apps-section section-pad" id="apps"><div className="container"><div className="apps-heading"><div><div className="section-kicker">02 / portfólio em movimento</div><h2>Algumas ideias que<br /><span>já ganharam forma.</span></h2></div><p>Conheça exemplos de soluções que podem nascer quando tecnologia e necessidade se encontram.</p></div><div className="apps-grid"><article className="app-showcase app-finance"><div className="app-image-wrap"><img src="/manus-storage/vmp-controle-financeiro_5de0e8e2.jpg" alt="Mockup do app Controle Financeiro" /></div><div className="app-info"><span className="app-type">gestão financeira</span><h3>Controle Financeiro</h3><p>Mais clareza para acompanhar entradas, saídas e decisões do dia a dia.</p><a href="#conversa" className="app-link">Quero algo assim <ArrowRight size={15} /></a></div></article><article className="app-showcase app-agenda"><div className="app-image-wrap"><img src="/manus-storage/vmp-agenda-atendimento_10e7f854.jpg" alt="Mockup do app Agenda Atendimento" /></div><div className="app-info"><span className="app-type">agenda & atendimento</span><h3>Agenda Atendimento</h3><p>Organização simples para horários, clientes e uma rotina mais leve.</p><a href="#conversa" className="app-link">Quero algo assim <ArrowRight size={15} /></a></div></article><article className="app-showcase app-fiados"><div className="app-image-wrap"><img src="/manus-storage/vmp-vendas-fiados_2307ffd2.jpg" alt="Mockup do app Vendas Fiados" /></div><div className="app-info"><span className="app-type">vendas & relacionamento</span><h3>Vendas Fiados</h3><p>Controle de clientes e pagamentos para vender com mais segurança.</p><a href="#conversa" className="app-link">Quero algo assim <ArrowRight size={15} /></a></div></article><article className="app-showcase app-studio"><div className="app-image-wrap"><img src="/studioflow-apk.png" alt="Ícone real do aplicativo StudioFlow extraído do APK" /></div><div className="app-info"><span className="app-type">fluxo de trabalho</span><h3>StudioFlow</h3><p>Projetos, tarefas e processos criativos no mesmo lugar.</p><a href="#conversa" className="app-link">Quero algo assim <ArrowRight size={15} /></a></div></article><article className="app-showcase app-recipes"><div className="app-image-wrap"><img src="/manus-storage/vmp-livro-receitas_82b1fab7.jpg" alt="Mockup do app Livro de Receitas" /></div><div className="app-info"><span className="app-type">conteúdo & cozinha</span><h3>Livro de Receitas</h3><p>Receitas organizadas para transformar inspiração em prática.</p><a href="#conversa" className="app-link">Quero algo assim <ArrowRight size={15} /></a></div></article></div></div></section>

      <section className="demo-section" id="demo"><div className="container demo-layout"><div className="demo-copy"><div className="section-kicker light">02 / uma prévia</div><h2>Antes de construir,<br /><em>você já pode sentir.</em></h2><p>Esta é uma pequena demonstração de como uma solução VMP pode organizar informações e próximos passos em uma experiência simples.</p><div className="demo-note"><span><Sparkles size={16} /></span><p><strong>É só uma prévia.</strong><br />Cada projeto começa de um jeito — o seu será desenhado para a sua realidade.</p></div></div><DemoPhone /></div></section>

      <section className="process section-pad" id="processo"><div className="container"><div className="process-heading"><div className="section-kicker">03 / como acontece</div><h2>Clareza em cada<br /><span>etapa do caminho.</span></h2></div><div className="steps-grid">{steps.map((step) => <article className="step" key={step.number}><span className="step-number">{step.number}</span><h3>{step.title}</h3><p>{step.text}</p></article>)}</div></div></section>

      <section className="contact section-pad" id="conversa"><div className="container contact-card"><div className="contact-orb" /><div className="section-kicker light">04 / seu próximo passo</div><h2>Tem uma ideia na cabeça?<br /><em>Vamos dar forma a ela.</em></h2><p>Conte o que você imagina. A primeira conversa é para entender, não para complicar.</p><a className="button button-primary lime-button" href="mailto:ola@vmp.studio">Começar uma conversa <ArrowRight size={17} /></a><span className="contact-email">ola@vmp.studio</span></div></section>

      <footer className="footer"><div className="container footer-inner"><a className="brand" href="#top"><span>V</span>MP<small>studio</small></a><span>Aplicativos sob medida para negócios em movimento.</span><span>© 2026 VMP</span></div></footer>
    </main>
  );
}
